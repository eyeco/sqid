/*---------------------------------------------------------------------------------------------
* Copyright (C) 2024 eyeco https://github.com/eyeco https://www.rolandaigner.com
* This file is part of the sqid Visual Programming Environment
*
* Licensed under the GPL3 License. See LICENSE file in the package root for license information.
*
* You should have received a copy of the GNU General Public License
* along with this code. If not, see < http://www.gnu.org/licenses/>.
*--------------------------------------------------------------------------------------------*/


#pragma once

#include <config.h>

#include <processing/op.h>

// include nlohmann JSON if you plan to load/save your custom parameters
#include <fileIO/json.h>

namespace sqid
{
	namespace Plugins
	{
		// put your operators declarations here
		class PluginTemplate : public sqid::Op
		{
		private:
			bool _swapOutput;

		protected:
			//to provide your processing code, override protected member bool process()
			virtual bool process();

		public:
			explicit PluginTemplate();
			virtual ~PluginTemplate();

			// to support customization of processing parameters using GUI (via ImGui),
			//		override the public member bool drawUI() and surround declaration and
			//		definition with #ifdef __SUPPORT_GUI ... #endif
#ifdef __SUPPORT_GUI
			virtual bool drawUI();
#endif

			//to specify custom input/output pins, override public member void createPins()
			virtual void createPins();

			// to save these settings to scene JSON (and load them at startup), override 
			//		the public members bool loadFromJSON( const nlohmann::json &j ) and
			//		bool saveToJSON( nlohmann::json &j )
			virtual bool loadFromJSON( const nlohmann::json &j );
			virtual bool saveToJSON( nlohmann::json &j ) const;

			//use the DECLARE_OP_DESC macro to declare your necessary generic interface, 
			// consisting of public members
			//		virtual const GUID &getClassID() const;
			//		virtual const char *getName() const;
			//		virtual const char *getPath() const;
			//		static const GUID &ClassID();
			//		static const char *Name();
			//		static const char *Path();
			DECLARE_OP_DESC;
		};
	}
}
