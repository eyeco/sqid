/*---------------------------------------------------------------------------------------------
* Copyright (C) 2024 eyeco https://github.com/eyeco https://www.rolandaigner.com
* This file is part of the sqid Visual Programming Environment
*
* Licensed under the GPL3 License. See LICENSE file in the package root for license information.
*
* You should have received a copy of the GNU General Public License
* along with this code. If not, see < http://www.gnu.org/licenses/>.
*--------------------------------------------------------------------------------------------*/


#include "pluginTemplateOps.h"

#include <processing/opFactory.h>

#include <app.h>

// include ImGui header if you implement a inspector UI for tuning parameters
#include <imgui/imgui.h>

// place your additional 3rd party include directives here
//#include <...>

namespace sqid
{
	namespace Plugins
	{
		//use the DEFINE_OP_DESC macro to define your necessary generic interface, 
		// consisting of public members
		//		virtual const GUID &getClassID() const;
		//		virtual const char *getName() const;
		//		virtual const char *getPath() const;
		//		static const GUID &ClassID();
		//		static const char *Name();
		//		static const char *Path();
		// !!! MAKE SURE YOU USE A UNIQUE GUID !!!
		// recommended tool in MSVS: go to Tools > Create GUID, then click "New 
		// GUID" and "Copy", which moves it to the clipboard
		DEFINE_OP_DESC( PluginTemplate, "pluginTemplate", "/plugins",
			"xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx" );

		PluginTemplate::PluginTemplate() :
			Op(),
			_swapOutput( false )
		{}

		PluginTemplate::~PluginTemplate()
		{
			//make sure to clean and free all your resources
		}

		void PluginTemplate::createPins()
		{
			//specify all your input pins and also specify respective data types. make sure
			// to use unique names for each of them.
			addInlet( new InletPin( new DataContainer<SampleFrame>(), "in-1", this ) );
			addInlet( new InletPin( new DataContainer<SampleFrame>(), "in-2", this ) );

			//specify all your output pins and also specify respective data types. make sure
			// to use unique names for each of them.
			addOutlet( new OutletPin( new DataContainer<SampleFrame>(), "out-1", this ) );
			addOutlet( new OutletPin( new DataContainer<SampleFrame>(), "out-2", this ) );
		}

#ifdef __SUPPORT_GUI
		bool PluginTemplate::drawUI()
		{
			//don't forget to call the base class method, since generic
			// operator UI elements have to be operated
			if( !Op::drawUI() )
				return false;

			//put your UI stuff here
			ImGui::Checkbox( "swap", &_swapOutput );

			return true;
		}
#endif

		bool PluginTemplate::process()
		{
			//fetch incoming frames from all inputs. make sure to 
			// delete them, since fetchInput handles over ownership,
			// so you are responsible for freeing memory
			SampleFrame* sf1 = fetchInput<SampleFrame>( "in-1" );
			SampleFrame* sf2 = fetchInput<SampleFrame>( "in-2" );

			//check if there was data incoming at in-1
			if( sf1 )
			{
				//draw frame to the visualizer
				drawFrame( sf1 );

				//output to either out-2 or out-1, depending on the state
				// of your UI checkbox
				pushOutput( _swapOutput ? "out-2" : "out-1", sf1 );
				safeDelete( sf1 );
			}

			//check if there was data incoming at in-2
			if( sf2 )
			{
				//at the moment, there is no generic way to draw multiple
				// frames in the default visualizer, so we decide to skip
				// drawing of frames incoming at in-2

				//output to either out-1 or out-2, depending on the state
				// of your UI checkbox
				pushOutput( _swapOutput ? "out-1" : "out-2", sf2 );
				safeDelete( sf2 );
			}

			//return if either of the inputs has still pending input so the 
			// caller knows whether to call process() again. Note that all 
			// pending data will be processed before proceeding, so data does
			// not accumulate and cause proglems in the long run
			return inputPending( "in-1" ) || inputPending( "in-2" );
		}

		bool PluginTemplate::loadFromJSON( const nlohmann::json &j )
		{
			//don't forget to call the base class method, since generic
			// operator data has to be loaded
			bool ret = Op::loadFromJSON( j );

			//load all your properties here, make sure the data types 
			// are correct -- to be on the safe side, you may specify
			// template parameters
			load<bool>( j, "swap", _swapOutput );

			return ret;
		}

		bool PluginTemplate::saveToJSON( nlohmann::json &j ) const
		{
			//don't forget to call the base class method, since generic
			// operator data has to be saved
			bool ret = Op::saveToJSON( j );

			//save all your properties here, make sure the data types
			// are correct -- to be on the safe side, you may specify
			// template parameters
			save<bool>( j, "swap", _swapOutput );

			return ret;
		}
	}
}