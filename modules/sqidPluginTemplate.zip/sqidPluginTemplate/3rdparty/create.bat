@echo off

@REM set "lib=myLibDependencyName"

@REM cd /d "%~dp0"

@REM if not exist "%lib%" (
@REM     echo extracting %lib%
@REM     if exist "%lib%.tar.gz" (
@REM         tar -xzf "%lib%.tar.gz"
@REM         echo done
@REM     ) else (
@REM         echo ERROR: archive %lib%.tar.gz not fround
@REM     )
@REM ) else (
@REM     echo found "%lib%", nothing to do
@REM )